package com.example.parkir

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

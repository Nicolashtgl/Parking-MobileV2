import 'package:hexcolor/hexcolor.dart';

class GlobalColors {
  static HexColor mainColor = HexColor('#EAEAEA');
  static HexColor textColor = HexColor('#00000');
}
